package com.zadalmumin.app;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

public class NativeBridge {
    private final MainActivity activity;
    private final Context ctx;

    NativeBridge(MainActivity a) {
        activity = a;
        ctx = a.getApplicationContext();
    }

    @JavascriptInterface
    public boolean isNative() { return true; }

    /** Legacy: the app now sends its settings and the native planner computes everything itself. */
    @JavascriptInterface
    public void schedule(String eventsJson) {
        if (!Scheduler.prefs(ctx).contains("cfg")) Scheduler.replaceAll(ctx, eventsJson);
    }

    @JavascriptInterface
    public void setConfig(String json) {
        String old = Scheduler.prefs(ctx).getString("cfg", "");
        Scheduler.prefs(ctx).edit().putString("cfg", json).apply();
        if (!json.equals(old) || Scheduler.prefs(ctx).getInt("count", 0) == 0) Planner.planAll(ctx);
        else WidgetUpdater.updateAll(ctx);
    }

    @JavascriptInterface
    public boolean pinWidget(String kind) {
        if (Build.VERSION.SDK_INT < 26) return false;
        try {
            android.appwidget.AppWidgetManager m = android.appwidget.AppWidgetManager.getInstance(ctx);
            if (!m.isRequestPinAppWidgetSupported()) return false;
            Class<?> cls = "caps".equals(kind) ? CapsWidget.class : DayWidget.class;
            return m.requestPinAppWidget(new android.content.ComponentName(ctx, cls), null, null);
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public void setTaskDefs(String json) {
        Scheduler.prefs(ctx).edit().putString("taskDefs", json).apply();
    }

    @JavascriptInterface
    public void saveTasks(String dateKey, String json) {
        Scheduler.prefs(ctx).edit().putString("tk." + dateKey, json).putString("lastDate", dateKey).apply();
    }

    @JavascriptInterface
    public String getTasks(String dateKey) {
        return Scheduler.prefs(ctx).getString("tk." + dateKey, "{}");
    }

    @JavascriptInterface
    public void test(String kind) {
        try {
            if ("adhan".equals(kind)) {
                JSONObject ev = new JSONObject();
                ev.put("type", "adhan");
                ev.put("title", "تجربة الأذان");
                ev.put("body", "هكذا يصلك الأذان في وقت الصلاة");
                ev.put("sound", Scheduler.prefs(ctx).getString("lastAdhanSound", "adhan1"));
                ev.put("vol", 0.9);
                AlarmReceiver.handle(ctx, ev);
            } else {
                JSONObject ev = new JSONObject();
                ev.put("type", "tkdaily");
                ev.put("date", Scheduler.prefs(ctx).getString("lastDate", ""));
                ev.put("title", "المهام اليومية");
                AlarmReceiver.handle(ctx, ev);
            }
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void openSettings() {
        activity.runOnUiThread(() -> {
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
                    if (am != null && !am.canScheduleExactAlarms()) {
                        Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.getPackageName()));
                        activity.startActivity(i);
                        return;
                    }
                }
                if (Build.VERSION.SDK_INT >= 23) {
                    PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                    if (pm != null && !pm.isIgnoringBatteryOptimizations(ctx.getPackageName())) {
                        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.getPackageName()));
                        activity.startActivity(i);
                        return;
                    }
                }
                Intent i;
                if (Build.VERSION.SDK_INT >= 26) {
                    i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.getPackageName());
                } else {
                    i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.getPackageName()));
                }
                activity.startActivity(i);
            } catch (Exception ignored) { }
        });
    }
}
