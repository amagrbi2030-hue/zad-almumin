package com.zadalmumin.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            JSONObject ev = new JSONObject(intent.getStringExtra("ev"));
            handle(context.getApplicationContext(), ev);
        } catch (Exception ignored) { }
    }

    static void handle(Context c, JSONObject ev) throws Exception {
        String type = ev.optString("type");
        String title = ev.optString("title", "زاد المؤمن");
        String body = ev.optString("body", "");
        String sound = ev.optString("sound", "silent");
        boolean vib = ev.optBoolean("vib", true);
        int nid = (int) (ev.optLong("at", System.currentTimeMillis()) / 1000 % 100000);

        switch (type) {
            case "adhan": {
                Intent s = new Intent(c, AdhanService.class);
                s.putExtra("title", title);
                s.putExtra("body", body);
                s.putExtra("sound", sound);
                s.putExtra("vol", (float) ev.optDouble("vol", 0.9));
                try {
                    if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
                } catch (Exception e) {
                    NotificationHelper.show(c, nid, NotificationHelper.CH_ALERT, title, body, vib);
                }
                break;
            }
            case "tkpray": {
                JSONObject st = tasksOf(c, ev.optString("date"));
                if (!st.has(ev.optString("key"))) NotificationHelper.show(c, nid, NotificationHelper.CH_TASKS, title, body, true);
                break;
            }
            case "tkdaily": {
                dailySummary(c, ev.optString("date"), nid);
                break;
            }
            default: {
                String ch = "silent".equals(sound) ? NotificationHelper.CH_SILENT : NotificationHelper.CH_ALERT;
                NotificationHelper.show(c, nid, ch, title, body, vib);
            }
        }
    }

    static JSONObject tasksOf(Context c, String date) {
        try { return new JSONObject(Scheduler.prefs(c).getString("tk." + date, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    static void dailySummary(Context c, String date, int nid) throws Exception {
        JSONObject st = tasksOf(c, date);
        JSONArray defs = new JSONArray(Scheduler.prefs(c).getString("taskDefs", "[]"));
        int total = 0, done = 0;
        List<String> left = new ArrayList<>();
        List<String> finished = new ArrayList<>();
        for (int i = 0; i < defs.length(); i++) {
            JSONObject d = defs.getJSONObject(i);
            JSONArray ids = d.getJSONArray("ids");
            int k = 0;
            for (int j = 0; j < ids.length(); j++) if (st.has(ids.getString(j))) k++;
            total += ids.length();
            done += k;
            if (k == ids.length()) finished.add(d.getString("t"));
            else left.add(d.getString("t") + (ids.length() > 1 ? " (" + (ids.length() - k) + ")" : ""));
        }
        if (defs.length() == 0) return;
        if (left.isEmpty()) {
            NotificationHelper.show(c, nid, NotificationHelper.CH_TASKS, "ما شاء الله! أتممتِ مهام اليوم كلها",
                    "أنجزتِ " + done + " من " + total + " — " + TextUtils.join("، ", finished), true);
        } else {
            String body = "أنجزتِ " + done + " من " + total + "\nبقي: " + TextUtils.join("، ", left)
                    + (finished.isEmpty() ? "" : "\nالمكتملة: " + TextUtils.join("، ", finished));
            NotificationHelper.show(c, nid, NotificationHelper.CH_TASKS, "مهام اليوم لم تكتمل (" + left.size() + ")", body, true);
        }
    }
}
