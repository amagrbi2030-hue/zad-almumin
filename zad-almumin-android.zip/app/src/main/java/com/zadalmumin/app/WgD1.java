package com.zadalmumin.app;

/** Home-screen widget «الساعة الإسلامية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD1 extends SnapWidget { }
