package com.zadalmumin.app;

/** Home-screen widget «التاريخ الزجاجية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgWd extends SnapWidget { }
