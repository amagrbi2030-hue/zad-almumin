package com.zadalmumin.app;

/** Home-screen widget «النجمية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgStar extends SnapWidget { }
