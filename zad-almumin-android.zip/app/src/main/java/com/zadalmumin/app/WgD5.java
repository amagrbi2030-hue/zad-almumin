package com.zadalmumin.app;

/** Home-screen widget «بطاقة المسجد والصلاة» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD5 extends SnapWidget { }
