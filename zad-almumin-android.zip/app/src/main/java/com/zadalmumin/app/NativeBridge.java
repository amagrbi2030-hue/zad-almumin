package com.zadalmumin.app;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

public class NativeBridge {
    private final MainActivity activity;
    private final Context ctx;

    NativeBridge(MainActivity a) {
        activity = a;
        ctx = a.getApplicationContext();
    }

    @JavascriptInterface
    public boolean isNative() { return true; }

    /** Legacy: the app now sends its settings and the native planner computes everything itself. */
    @JavascriptInterface
    public void schedule(String eventsJson) {
        if (!Scheduler.prefs(ctx).contains("cfg")) Scheduler.replaceAll(ctx, eventsJson);
    }

    @JavascriptInterface
    public void setConfig(String json) {
        String old = Scheduler.prefs(ctx).getString("cfg", "");
        Scheduler.prefs(ctx).edit().putString("cfg", json).apply();
        if (!json.equals(old) || Scheduler.prefs(ctx).getInt("count", 0) == 0) Planner.planAll(ctx);
        else WidgetUpdater.updateAll(ctx);
    }

    @JavascriptInterface
    public boolean pinWidget(String kind) {
        if (Build.VERSION.SDK_INT < 26) return false;
        try {
            android.appwidget.AppWidgetManager m = android.appwidget.AppWidgetManager.getInstance(ctx);
            if (!m.isRequestPinAppWidgetSupported()) return false;
            int si = SnapKinds.index(kind);
            Class<?> cls = si >= 0 ? SnapKinds.CLASSES[si] : "caps".equals(kind) ? CapsWidget.class : DayWidget.class;
            return m.requestPinAppWidget(new android.content.ComponentName(ctx, cls), null, null);
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public void setTaskDefs(String json) {
        Scheduler.prefs(ctx).edit().putString("taskDefs", json).apply();
    }

    @JavascriptInterface
    public void saveTasks(String dateKey, String json) {
        Scheduler.prefs(ctx).edit().putString("tk." + dateKey, json).putString("lastDate", dateKey).apply();
    }

    // ---- image-frame widgets: the page renders each design and streams the frames here ----
    private static final java.util.Map<String, org.json.JSONArray> PENDING = new java.util.HashMap<>();
    private static final java.util.Map<String, Long> GEN = new java.util.HashMap<>();

    @JavascriptInterface
    public String placedWidgets() {
        org.json.JSONArray a = new org.json.JSONArray();
        try {
            android.appwidget.AppWidgetManager m = android.appwidget.AppWidgetManager.getInstance(ctx);
            for (int i = 0; i < SnapKinds.KINDS.length; i++)
                if (m.getAppWidgetIds(new android.content.ComponentName(ctx, SnapKinds.CLASSES[i])).length > 0) a.put(SnapKinds.KINDS[i]);
        } catch (Exception ignored) { }
        return a.toString();
    }

    @JavascriptInterface
    public void wgBegin(String kind, String meta) {
        synchronized (PENDING) { PENDING.put(kind, new org.json.JSONArray()); GEN.put(kind, System.currentTimeMillis()); }
        Scheduler.prefs(ctx).edit().putString("wgnew." + kind, meta).apply();
    }

    @JavascriptInterface
    public void wgFrame(String kind, String from, String b64) {
        try {
            long gen;
            synchronized (PENDING) { Long g = GEN.get(kind); if (g == null) return; gen = g; }
            String name = kind + "_" + gen + "_" + from + ".img";
            byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            java.io.FileOutputStream out = new java.io.FileOutputStream(new java.io.File(WidgetUpdater.snapDir(ctx), name));
            try { out.write(data); } finally { out.close(); }
            synchronized (PENDING) {
                org.json.JSONArray a = PENDING.get(kind);
                if (a != null) a.put(new org.json.JSONArray().put(Long.parseLong(from)).put(name));
            }
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void wgCommit(String kind) {
        org.json.JSONArray a;
        long gen;
        synchronized (PENDING) { a = PENDING.remove(kind); Long g = GEN.remove(kind); gen = g == null ? 0 : g; }
        if (a == null || a.length() == 0) return;
        try {
            JSONObject meta = new JSONObject(Scheduler.prefs(ctx).getString("wgnew." + kind, "{}"));
            meta.put("frames", a);
            Scheduler.prefs(ctx).edit().putString("wgm." + kind, meta.toString()).remove("wgnew." + kind).apply();
            String keep = kind + "_" + gen + "_";
            java.io.File[] fs = WidgetUpdater.snapDir(ctx).listFiles();
            if (fs != null) for (java.io.File f : fs)
                if (f.getName().startsWith(kind + "_") && !f.getName().startsWith(keep)) f.delete();
        } catch (Exception ignored) { }
        WidgetUpdater.updateAll(ctx);
    }

    @JavascriptInterface
    public String getTasks(String dateKey) {
        return Scheduler.prefs(ctx).getString("tk." + dateKey, "{}");
    }

    @JavascriptInterface
    public void test(String kind) {
        try {
            if ("adhan".equals(kind)) {
                JSONObject ev = new JSONObject();
                ev.put("type", "adhan");
                ev.put("title", "تجربة الأذان");
                ev.put("body", "هكذا يصلك الأذان في وقت الصلاة");
                ev.put("sound", Scheduler.prefs(ctx).getString("lastAdhanSound", "adhan1"));
                ev.put("vol", 0.9);
                AlarmReceiver.handle(ctx, ev);
            } else {
                JSONObject ev = new JSONObject();
                ev.put("type", "tkdaily");
                ev.put("date", Scheduler.prefs(ctx).getString("lastDate", ""));
                ev.put("title", "المهام اليومية");
                AlarmReceiver.handle(ctx, ev);
            }
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void openSettings() {
        activity.runOnUiThread(() -> {
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
                    if (am != null && !am.canScheduleExactAlarms()) {
                        Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.getPackageName()));
                        activity.startActivity(i);
                        return;
                    }
                }
                if (Build.VERSION.SDK_INT >= 23) {
                    PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                    if (pm != null && !pm.isIgnoringBatteryOptimizations(ctx.getPackageName())) {
                        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.getPackageName()));
                        activity.startActivity(i);
                        return;
                    }
                }
                Intent i;
                if (Build.VERSION.SDK_INT >= 26) {
                    i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.getPackageName());
                } else {
                    i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.getPackageName()));
                }
                activity.startActivity(i);
            } catch (Exception ignored) { }
        });
    }
}
