package com.zadalmumin.app;

/** Home-screen widget «البطاقة الزمردية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD2 extends SnapWidget { }
