package com.zadalmumin.app;

import java.util.HashMap;
import java.util.Map;

/** Offline astronomical prayer-time calculation (port of the app's engine.js). Returns UTC epoch-ms. */
public final class PrayerEngine {
    private PrayerEngine() { }

    private static double dtr(double d) { return d * Math.PI / 180; }
    private static double rtd(double r) { return r * 180 / Math.PI; }
    private static double sin(double d) { return Math.sin(dtr(d)); }
    private static double cos(double d) { return Math.cos(dtr(d)); }
    private static double tan(double d) { return Math.tan(dtr(d)); }
    private static double asin(double x) { return rtd(Math.asin(x)); }
    private static double acos(double x) { return rtd(Math.acos(Math.max(-1, Math.min(1, x)))); }
    private static double atan2(double y, double x) { return rtd(Math.atan2(y, x)); }
    private static double acot(double x) { return rtd(Math.atan(1 / x)); }
    private static double fix(double a, double b) { a = a - b * Math.floor(a / b); return a < 0 ? a + b : a; }

    /** {fajrAngle, ishaAngle, ishaMinutes(or -1)} */
    private static double[] method(String id) {
        if (id == null) id = "UMM_AL_QURA";
        switch (id) {
            case "MWL": return new double[]{18, 17, -1};
            case "EGYPT": return new double[]{19.5, 17.5, -1};
            case "KARACHI": return new double[]{18, 18, -1};
            case "DUBAI": return new double[]{18.2, 18.2, -1};
            case "KUWAIT": return new double[]{18, 17.5, -1};
            case "QATAR": return new double[]{18, 0, 90};
            case "ISNA": return new double[]{15, 15, -1};
            default: return new double[]{18.5, 0, 90};
        }
    }

    private static double julian(int y, int m, int d) {
        if (m <= 2) { y -= 1; m += 12; }
        double A = Math.floor(y / 100.0), B = 2 - A + Math.floor(A / 4);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
    }

    private static double[] sunPos(double jd) {
        double D = jd - 2451545.0;
        double g = fix(357.529 + 0.98560028 * D, 360), q = fix(280.459 + 0.98564736 * D, 360);
        double L = fix(q + 1.915 * sin(g) + 0.020 * sin(2 * g), 360);
        double e = 23.439 - 0.00000036 * D;
        double RA = atan2(cos(e) * sin(L), cos(L)) / 15;
        return new double[]{asin(sin(e) * sin(L)), q / 15 - fix(RA, 24)};
    }

    public static Map<String, Long> compute(int y, int m, int d, double lat, double lng, String methodId, String madhab) {
        final double[] meth = method(methodId);
        final double jd0 = julian(y, m, d) - lng / (15 * 24);
        double fajr = 5, sunrise = 6, dhuhr = 12, asr = 13, maghrib = 18, isha = 18;
        for (int i = 0; i < 2; i++) {
            double nFajr = angleTime(jd0, lat, meth[0], fajr / 24, true);
            double nSunrise = angleTime(jd0, lat, 0.833, sunrise / 24, true);
            double nDhuhr = noon(jd0, dhuhr / 24);
            double decl = sunPos(jd0 + asr / 24)[0];
            double factor = "HANAFI".equals(madhab) ? 2 : 1;
            double nAsr = angleTime(jd0, lat, -acot(factor + tan(Math.abs(lat - decl))), asr / 24, false);
            double nMaghrib = angleTime(jd0, lat, 0.833, maghrib / 24, false);
            double nIsha = meth[2] > 0 ? nMaghrib + meth[2] / 60 : angleTime(jd0, lat, meth[1], isha / 24, false);
            fajr = nFajr; sunrise = nSunrise; dhuhr = nDhuhr; asr = nAsr; maghrib = nMaghrib; isha = nIsha;
        }
        double night = 24 - (maghrib - sunrise);
        if (Double.isNaN(fajr) || sunrise - fajr > night / 2) fajr = sunrise - night / 2;
        if (Double.isNaN(isha) || isha - maghrib > night / 2) isha = maghrib + night / 2;
        java.util.GregorianCalendar gc = new java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC"));
        gc.clear(); gc.set(y, m - 1, d, 0, 0, 0);
        long base = gc.getTimeInMillis();
        Map<String, Long> out = new HashMap<>();
        out.put("fajr", toMs(base, fajr, lng));
        out.put("sunrise", toMs(base, sunrise, lng));
        out.put("dhuhr", toMs(base, dhuhr, lng));
        out.put("asr", toMs(base, asr, lng));
        out.put("maghrib", toMs(base, maghrib, lng));
        out.put("isha", toMs(base, isha, lng));
        return out;
    }

    private static long toMs(long base, double t, double lng) {
        double h = t - lng / 15;
        return Math.round((base + h * 3600000.0) / 60000.0) * 60000L;
    }

    private static double noon(double jd0, double t) { return fix(12 - sunPos(jd0 + t)[1], 24); }

    private static double angleTime(double jd0, double lat, double angle, double t, boolean ccw) {
        double decl = sunPos(jd0 + t)[0];
        double T = acos((-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat))) / 15;
        return noon(jd0, t) + (ccw ? -T : T);
    }
}
