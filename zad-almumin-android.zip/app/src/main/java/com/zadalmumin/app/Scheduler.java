package com.zadalmumin.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/** Stores the 30-day event list computed by the app and registers one exact alarm per event. Works fully offline. */
public final class Scheduler {
    static final int BASE = 1000;

    private Scheduler() { }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("zad", Context.MODE_PRIVATE);
    }

    static synchronized void replaceAll(Context c, String json) {
        cancelAll(c);
        prefs(c).edit().putString("events", json).apply();
        scheduleAll(c);
    }

    static synchronized void cancelAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        int n = prefs(c).getInt("count", 0);
        for (int i = 0; i < n; i++) {
            PendingIntent pi = PendingIntent.getBroadcast(c, BASE + i, new Intent(c, AlarmReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null && am != null) { am.cancel(pi); pi.cancel(); }
        }
        prefs(c).edit().putInt("count", 0).apply();
    }

    static synchronized void scheduleAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        String json = prefs(c).getString("events", "[]");
        int n = 0;
        String lastAdhan = null;
        try {
            JSONArray arr = new JSONArray(json);
            long now = System.currentTimeMillis();
            for (int i = 0; i < arr.length() && n < 450; i++) {
                JSONObject ev = arr.getJSONObject(i);
                long at = ev.getLong("at");
                if ("adhan".equals(ev.optString("type")) && lastAdhan == null) lastAdhan = ev.optString("sound", "adhan1");
                if (at <= now) continue;
                Intent intent = new Intent(c, AlarmReceiver.class);
                intent.putExtra("ev", ev.toString());
                PendingIntent pi = PendingIntent.getBroadcast(c, BASE + n, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                setExact(am, at, pi);
                n++;
            }
        } catch (Exception ignored) { }
        SharedPreferences.Editor ed = prefs(c).edit().putInt("count", n);
        if (lastAdhan != null) ed.putString("lastAdhanSound", lastAdhan);
        ed.apply();
    }

    private static void setExact(AlarmManager am, long at, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }
}
