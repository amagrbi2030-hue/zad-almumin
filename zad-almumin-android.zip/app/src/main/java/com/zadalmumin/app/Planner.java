package com.zadalmumin.app;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/**
 * Computes prayer times natively (offline) from the settings saved by the app, and keeps a rolling
 * 7-day schedule of adhan / iqama / pre-alert / task reminders. Re-plans itself every midnight, so
 * alerts keep coming even if the app is never opened again.
 */
public final class Planner {
    private Planner() { }

    static final String[] KEYS = {"fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha", "midnight", "lastThird"};
    static final String[] SIX = {"fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha"};
    static final String[] PRAYERS = {"fajr", "dhuhr", "asr", "maghrib", "isha"};

    static JSONObject cfg(Context c) {
        try { return new JSONObject(Scheduler.prefs(c).getString("cfg", "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    static TimeZone tz(JSONObject cfg) {
        String id = cfg.optString("tz", "");
        if (id.isEmpty() || "device".equals(id)) return TimeZone.getDefault();
        return TimeZone.getTimeZone(id);
    }

    static boolean isPrayer(String k) {
        for (String p : PRAYERS) if (p.equals(k)) return true;
        return false;
    }

    static String name(String k, boolean friday) {
        switch (k) {
            case "fajr": return "الفجر";
            case "sunrise": return "الشروق";
            case "dhuhr": return friday ? "الجمعة" : "الظهر";
            case "asr": return "العصر";
            case "maghrib": return "المغرب";
            case "isha": return "العشاء";
            case "midnight": return "منتصف الليل";
            default: return "الثلث الأخير";
        }
    }

    static String fullName(String k, boolean friday) {
        if ("sunrise".equals(k)) return "شروق الشمس";
        if ("midnight".equals(k)) return "منتصف الليل";
        if ("lastThird".equals(k)) return "الثلث الأخير من الليل";
        return "صلاة " + name(k, friday);
    }

    static String digits(JSONObject cfg, String s) {
        JSONObject disp = cfg.optJSONObject("display");
        if (disp != null && !disp.optBoolean("arabicDigits", true)) return s;
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) b.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        return b.toString();
    }

    static String fmt(JSONObject cfg, long ms, boolean withPeriod) {
        Calendar c = Calendar.getInstance(tz(cfg));
        c.setTimeInMillis(ms);
        int h = c.get(Calendar.HOUR_OF_DAY), m = c.get(Calendar.MINUTE);
        JSONObject disp = cfg.optJSONObject("display");
        boolean h24 = disp != null && disp.optBoolean("time24", false);
        String s;
        if (h24) s = String.format(Locale.US, "%02d:%02d", h, m);
        else {
            int h12 = h % 12 == 0 ? 12 : h % 12;
            s = String.format(Locale.US, "%d:%02d", h12, m) + (withPeriod ? (h < 12 ? " ص" : " م") : "");
        }
        return digits(cfg, s);
    }

    static JSONObject prayerCfg(JSONObject cfg, String k) {
        JSONObject ps = cfg.optJSONObject("prayers");
        JSONObject p = ps == null ? null : ps.optJSONObject(k);
        if (p != null) return p;
        p = new JSONObject();
        try {
            boolean pr = isPrayer(k);
            p.put("alert", pr); p.put("sound", pr ? "adhan1" : "reminder"); p.put("volume", 0.9); p.put("vibrate", true);
            p.put("offset", 0); p.put("preEnabled", false); p.put("preMinutes", 10);
            p.put("iqamaEnabled", pr); p.put("iqamaMinutes", "fajr".equals(k) ? 25 : "maghrib".equals(k) ? 10 : 20);
        } catch (Exception ignored) { }
        return p;
    }

    /** All times (with user offsets) for a civil date in the configured time zone. */
    static long[] day(JSONObject cfg, int y, int m, int d) {
        JSONObject loc = cfg.optJSONObject("location");
        JSONObject calc = cfg.optJSONObject("calc");
        double lat = loc == null ? 21.4225 : loc.optDouble("lat", 21.4225);
        double lng = loc == null ? 39.8262 : loc.optDouble("lng", 39.8262);
        String method = calc == null ? "UMM_AL_QURA" : calc.optString("method", "UMM_AL_QURA");
        String madhab = calc == null ? "SHAFI" : calc.optString("madhab", "SHAFI");
        Map<String, Long> r = PrayerEngine.compute(y, m, d, lat, lng, method, madhab);
        Calendar n = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        n.clear(); n.set(y, m - 1, d); n.add(Calendar.DATE, 1);
        Map<String, Long> nx = PrayerEngine.compute(n.get(Calendar.YEAR), n.get(Calendar.MONTH) + 1, n.get(Calendar.DATE), lat, lng, method, madhab);
        long night = nx.get("fajr") - r.get("maghrib");
        long[] out = new long[KEYS.length];
        for (int i = 0; i < KEYS.length; i++) {
            String k = KEYS[i];
            long raw = "midnight".equals(k) ? r.get("maghrib") + night / 2 : "lastThird".equals(k) ? r.get("maghrib") + night * 2 / 3 : r.get(k);
            out[i] = raw + prayerCfg(cfg, k).optLong("offset", 0) * 60000L;
        }
        return out;
    }

    static String dateKey(int y, int m, int d) { return String.format(Locale.US, "%04d-%02d-%02d", y, m, d); }

    static long localTime(JSONObject cfg, int y, int m, int d, int hh, int mm) {
        Calendar c = Calendar.getInstance(tz(cfg));
        c.clear(); c.set(y, m - 1, d, hh, mm, 0);
        return c.getTimeInMillis();
    }

    static synchronized void planAll(Context ctx) {
        JSONObject cfg = cfg(ctx);
        JSONArray ev = new JSONArray();
        long now = System.currentTimeMillis();
        String place = cfg.optJSONObject("location") == null ? "" : cfg.optJSONObject("location").optString("name", "");
        JSONObject tasks = cfg.optJSONObject("tasks");
        boolean tkPray = tasks == null || tasks.optBoolean("pray", true);
        boolean tkRemind = tasks == null || tasks.optBoolean("remind", true);
        String tkAt = tasks == null ? "21:00" : tasks.optString("at", "21:00");
        boolean tkWin = tasks == null || tasks.optBoolean("win", true);
        Calendar cal = Calendar.getInstance(tz(cfg));
        cal.setTimeInMillis(now);
        try {
            for (int i = 0; i < 7; i++) {
                int y = cal.get(Calendar.YEAR), m = cal.get(Calendar.MONTH) + 1, d = cal.get(Calendar.DATE);
                boolean fri = cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY;
                long[] t = day(cfg, y, m, d);
                String dk = dateKey(y, m, d);
                for (int j = 0; j < KEYS.length; j++) {
                    String k = KEYS[j];
                    JSONObject p = prayerCfg(cfg, k);
                    long at = t[j];
                    boolean pr = isPrayer(k);
                    String full = fullName(k, fri);
                    String body = fmt(cfg, at, true) + (place.isEmpty() ? "" : " · " + place);
                    double vol = p.optDouble("volume", 0.9);
                    boolean vib = p.optBoolean("vibrate", true);
                    if (p.optBoolean("preEnabled", false)) {
                        int pm = p.optInt("preMinutes", 10);
                        add(ev, now, at - pm * 60000L, "pre", "اقترب موعد " + full, "بعد " + digits(cfg, String.valueOf(pm)) + " دقائق · " + body, p.optString("preSound", "chime"), vol, vib, null, null);
                    }
                    if (p.optBoolean("alert", pr)) {
                        String snd = p.optString("sound", pr ? "adhan1" : "reminder");
                        add(ev, now, at, snd.matches("adhan\\d") ? "adhan" : "alert", "حان الآن وقت " + (pr ? full : name(k, fri)), body, snd, vol, vib, null, null);
                    }
                    if (pr && p.optBoolean("iqamaEnabled", true)) {
                        long iq = at + p.optInt("iqamaMinutes", 20) * 60000L;
                        add(ev, now, iq, "iqama", "حان الآن وقت الإقامة", "إقامة " + full + " · " + fmt(cfg, iq, true),
                                p.optBoolean("iqamaSoundEnabled", false) ? p.optString("iqamaSound", "iqama") : "silent", vol, vib, null, null);
                    }
                    if (pr && tkPray) {
                        add(ev, now, at + 45 * 60000L, "tkpray", "لم تُعلَّم صلاة " + name(k, false) + " بعد",
                                "دخل وقت " + name(k, false) + " منذ ٤٥ دقيقة — هل صلّيتها؟", "silent", 1, true, dk, "p_" + k);
                    }
                }
                if (tkWin) addWindows(ev, now, cfg, t, dk, cal);
                if (tkRemind) {
                    String[] hm = tkAt.split(":");
                    long at = localTime(cfg, y, m, d, Integer.parseInt(hm[0]), Integer.parseInt(hm[1]));
                    add(ev, now, at, "tkdaily", "المهام اليومية", "", "silent", 1, true, dk, null);
                }
                cal.add(Calendar.DATE, 1);
            }
            // re-plan shortly after the next local midnight so the 7-day window keeps rolling forever
            Calendar mid = Calendar.getInstance(tz(cfg));
            mid.setTimeInMillis(now);
            mid.add(Calendar.DATE, 1);
            mid.set(Calendar.HOUR_OF_DAY, 0); mid.set(Calendar.MINUTE, 1); mid.set(Calendar.SECOND, 0); mid.set(Calendar.MILLISECOND, 0);
            add(ev, now, mid.getTimeInMillis(), "replan", "", "", "silent", 1, false, null, null);
        } catch (Exception ignored) { }
        Scheduler.replaceAll(ctx, ev.toString());
        WidgetUpdater.updateAll(ctx);
    }

    static final long MIN = 60000L;

    /**
     * Time-window reminders (mirrors TK_WIN in the web app): sent only if the task is still unticked,
     * shortly before its time runs out.  t = day() times: 0 fajr, 1 sunrise, 2 dhuhr, 3 asr, 4 maghrib, 5 isha, 6 midnight, 7 lastThird.
     */
    static void addWindows(JSONArray ev, long now, JSONObject cfg, long[] t, String dk, Calendar cal) throws Exception {
        Calendar n = (Calendar) cal.clone();
        n.add(Calendar.DATE, 1);
        String nk = dateKey(n.get(Calendar.YEAR), n.get(Calendar.MONTH) + 1, n.get(Calendar.DATE));
        long duhaEnd = t[2] - 10 * MIN;
        win(ev, now, t[2] - 60 * MIN, "صلاة الضحى — قبل خروج وقتها",
                "بقي على خروج وقت الضحى نحو ساعة (حتى " + fmt(cfg, duhaEnd, true) + ").\nقال ﷺ: «يُصبِح على كلِّ سُلامى من أحدكم صدقة… ويُجزئ من ذلك ركعتان يركعهما من الضحى» رواه مسلم.",
                dk, "duha", null, null);
        win(ev, now, t[1] + 60 * MIN, "أذكار الصباح",
                "لم تُعلَّم أذكار الصباح بعد، ووقتها ممتد إلى ارتفاع النهار.\n﴿وسبِّح بحمد ربك قبل طلوع الشمس وقبل الغروب﴾",
                dk, "a_me", null, null);
        win(ev, now, Math.max(t[3] + 15 * MIN, t[4] - 45 * MIN), "أذكار المساء — قبل الغروب",
                "اقترب غروب الشمس (" + fmt(cfg, t[4], true) + ") ولم تُعلَّم أذكار المساء بعد — اغتنمي وقتها.",
                dk, "a_ev", null, null);
        win(ev, now, t[7], "دخل الثلث الأخير من الليل",
                "قال ﷺ: «ينزل ربنا تبارك وتعالى كل ليلة إلى السماء الدنيا حين يبقى ثلث الليل الآخر فيقول: من يدعوني فأستجيب له، من يسألني فأعطيه، من يستغفرني فأغفر له» متفق عليه.\nركعتان في جوف الليل.",
                dk, "qiyam", nk, "qiyam");
    }

    private static void win(JSONArray ev, long now, long at, String title, String body, String date, String key, String date2, String key2) throws Exception {
        if (at <= now + 2000) return;
        JSONObject o = new JSONObject();
        o.put("at", at); o.put("type", "tkwin"); o.put("title", title); o.put("body", body);
        o.put("sound", "silent"); o.put("vol", 1); o.put("vib", true);
        o.put("date", date); o.put("key", key);
        if (date2 != null) { o.put("date2", date2); o.put("key2", key2); }
        ev.put(o);
    }

    private static void add(JSONArray ev, long now, long at, String type, String title, String body, String sound,
                            double vol, boolean vib, String date, String key) throws Exception {
        if (at <= now + 2000) return;
        JSONObject o = new JSONObject();
        o.put("at", at); o.put("type", type); o.put("title", title); o.put("body", body);
        o.put("sound", sound); o.put("vol", vol); o.put("vib", vib);
        if (date != null) o.put("date", date);
        if (key != null) o.put("key", key);
        ev.put(o);
    }
}
