package com.zadalmumin.app;

/** Home-screen widget «العمودية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD9 extends SnapWidget { }
