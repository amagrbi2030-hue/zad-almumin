package com.zadalmumin.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

public class DayWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) { WidgetUpdater.updateAll(context.getApplicationContext()); }

    @Override
    public void onEnabled(Context context) { Planner.planAll(context.getApplicationContext()); }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager mgr, int id, Bundle opts) { WidgetUpdater.updateAll(context.getApplicationContext()); }
}
