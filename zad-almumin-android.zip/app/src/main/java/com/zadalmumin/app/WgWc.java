package com.zadalmumin.app;

/** Home-screen widget «الساعة الزجاجية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgWc extends SnapWidget { }
