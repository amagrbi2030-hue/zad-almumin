package com.zadalmumin.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The appearance chosen for a home-screen widget in the app's «استوديو مظاهر الويدجت»
 * (colours, gradient, opacity, frame, radius, tile tint, font scale), drawn into bitmaps for RemoteViews.
 */
final class Look {
    int[] cols; String grad; float ang, op, bw, r, tileA, fs; int text, icon, ind, frame, on;

    static Look from(JSONObject o, boolean caps) {
        Look l = new Look();
        if (o == null) o = new JSONObject();
        JSONArray c = o.optJSONArray("cols");
        String[] def = caps ? new String[]{"#C9CED8", "#7D8496"} : new String[]{"#141518"};
        int n = c == null || c.length() == 0 ? def.length : c.length();
        l.cols = new int[Math.max(2, n)];
        for (int i = 0; i < n; i++) l.cols[i] = col(c == null || c.length() == 0 ? def[i] : c.optString(i), Color.DKGRAY);
        if (n == 1) l.cols[1] = l.cols[0];
        l.grad = o.optString("grad", "linear");
        l.ang = (float) o.optDouble("ang", caps ? 160 : 180);
        l.op = (float) o.optDouble("op", caps ? .3 : 1);
        l.text = col(o.optString("text"), Color.WHITE);
        l.icon = col(o.optString("icon"), Color.WHITE);
        l.ind = col(o.optString("ind"), Color.WHITE);
        l.frame = col(o.optString("frame"), caps ? Color.WHITE : 0xFF4A4C52);
        l.on = col(o.optString("on"), 0xFF1D2230);
        l.bw = (float) o.optDouble("bw", 1.5);
        l.r = (float) o.optDouble("r", caps ? 34 : 28);
        l.tileA = (float) o.optDouble("tileA", caps ? .16 : .14);
        l.fs = (float) o.optDouble("fs", 1);
        return l;
    }

    static int col(String s, int def) {
        try { return s == null || s.isEmpty() ? def : Color.parseColor(s); } catch (Exception e) { return def; }
    }

    static int alpha(int c, float a) { return (Math.round(Math.max(0, Math.min(1, a)) * 255) << 24) | (c & 0xFFFFFF); }

    static double lum(int c) { return (.299 * Color.red(c) + .587 * Color.green(c) + .114 * Color.blue(c)) / 255.0; }

    /** Bitmap scale so the largest side stays under ~900px (RemoteViews memory budget). */
    private static float scale(float wDp, float hDp, float dn) { return Math.min(dn, 900f / Math.max(wDp, hDp)); }

    private static Shader shader(Look l, float w, float h) {
        if ("radial".equals(l.grad)) {
            float cx = w * .3f, cy = h * .2f, rad = (float) Math.hypot(Math.max(cx, w - cx), Math.max(cy, h - cy));
            return new RadialGradient(cx, cy, Math.max(1, rad), l.cols, null, Shader.TileMode.CLAMP);
        }
        double a = Math.toRadians("diagonal".equals(l.grad) ? 135 : l.ang); // CSS angle: 0 = to top, clockwise
        float dx = (float) Math.sin(a), dy = (float) -Math.cos(a);
        float len = Math.abs(w * dx) + Math.abs(h * dy);
        float cx = w / 2, cy = h / 2;
        return new LinearGradient(cx - dx * len / 2, cy - dy * len / 2, cx + dx * len / 2, cy + dy * len / 2, l.cols, null, Shader.TileMode.CLAMP);
    }

    private static void card(Canvas cv, Look l, RectF rc, float rad, float k) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(shader(l, rc.width(), rc.height()));
        p.setAlpha(Math.round(Math.max(0, Math.min(1, l.op)) * 255));
        cv.drawRoundRect(rc, rad, rad, p);
        if (l.bw > 0) {
            Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
            s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(l.bw * k); s.setColor(l.frame);
            float h = l.bw * k / 2;
            cv.drawRoundRect(new RectF(rc.left + h, rc.top + h, rc.right - h, rc.bottom - h), rad, rad, s);
        }
    }

    /** Background of «اليوم والصلاة». */
    static Bitmap panel(Look l, float wDp, float hDp, float dn) {
        float k = scale(wDp, hDp, dn);
        int w = Math.max(2, Math.round(wDp * k)), h = Math.max(2, Math.round(hDp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        card(new Canvas(b), l, new RectF(0, 0, w, h), Math.min(l.r * k, Math.min(w, h) / 2f), k);
        return b;
    }

    /** Outer glass shell + inner tray of «كبسولات الصلاة». */
    static Bitmap capsPanel(Look l, float wDp, float hDp, float dn) {
        float k = scale(wDp, hDp, dn);
        int w = Math.max(2, Math.round(wDp * k)), h = Math.max(2, Math.round(hDp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        card(cv, l, new RectF(0, 0, w, h), Math.min(l.r * k, Math.min(w, h) / 2f), k);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(alpha(l.text, l.tileA));
        float in = 8 * k, rr = Math.max(10, l.r - 8) * k;
        cv.drawRoundRect(new RectF(in, in, w - in, h - in), Math.min(rr, (h - 2 * in) / 2f), Math.min(rr, (h - 2 * in) / 2f), p);
        return b;
    }

    /** One vertical capsule. */
    static Bitmap capsule(Look l, float wDp, float hDp, float dn) {
        wDp = Math.max(20, wDp); hDp = Math.max(40, hDp);
        float k = dn;
        int w = Math.round(wDp * k), h = Math.round(hDp * k);
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float sw = 1.5f * k, rad = w / 2f;
        RectF rc = new RectF(sw / 2, sw / 2, w - sw / 2, h - sw / 2);
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG); f.setColor(alpha(l.text, l.tileA * .6f));
        cv.drawRoundRect(rc, rad, rad, f);
        Paint s = new Paint(Paint.ANTI_ALIAS_FLAG); s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(sw); s.setColor(alpha(l.frame, .6f));
        cv.drawRoundRect(rc, rad, rad, s);
        return b;
    }

    /** The 44dp time circle — outlined, or filled with the indicator colour for the next prayer. */
    static Bitmap circle(Look l, boolean filled, float dn) {
        int w = Math.round(44 * dn);
        Bitmap b = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float sw = 1.5f * dn, r = w / 2f - sw / 2;
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setColor(filled ? l.ind : alpha(l.text, .06f));
        cv.drawCircle(w / 2f, w / 2f, r, f);
        Paint s = new Paint(Paint.ANTI_ALIAS_FLAG); s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(sw);
        s.setColor(filled ? l.ind : alpha(l.frame, .7f));
        cv.drawCircle(w / 2f, w / 2f, r, s);
        return b;
    }
}
