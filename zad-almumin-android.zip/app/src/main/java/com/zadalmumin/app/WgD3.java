package com.zadalmumin.app;

/** Home-screen widget «الشريط الأفقي المصغّر» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD3 extends SnapWidget { }
