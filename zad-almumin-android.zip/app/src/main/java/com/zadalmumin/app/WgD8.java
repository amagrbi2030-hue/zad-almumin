package com.zadalmumin.app;

/** Home-screen widget «الذهبية الملكية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD8 extends SnapWidget { }
