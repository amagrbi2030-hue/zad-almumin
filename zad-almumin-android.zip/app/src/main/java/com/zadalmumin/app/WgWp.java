package com.zadalmumin.app;

/** Home-screen widget «الصلوات الزجاجية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgWp extends SnapWidget { }
