package com.zadalmumin.app;

/** Home-screen widget «المسجد الدائري الفاخر» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD0 extends SnapWidget { }
