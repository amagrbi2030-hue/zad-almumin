package com.zadalmumin.app;

/** Generated: widget kind ⇄ provider class ⇄ preview. */
final class SnapKinds {
    private SnapKinds() { }
    static final String[] KINDS = {"wc", "wd", "wp", "w2", "star", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9"};
    static final Class<?>[] CLASSES = {WgWc.class, WgWd.class, WgWp.class, WgW2.class, WgStar.class, WgD0.class, WgD1.class, WgD2.class, WgD3.class, WgD4.class, WgD5.class, WgD6.class, WgD7.class, WgD8.class, WgD9.class};
    static final int[] PREVIEWS = {R.drawable.preview_wc, R.drawable.preview_wd, R.drawable.preview_wp, R.drawable.preview_w2, R.drawable.preview_star, R.drawable.preview_d0, R.drawable.preview_d1, R.drawable.preview_d2, R.drawable.preview_d3, R.drawable.preview_d4, R.drawable.preview_d5, R.drawable.preview_d6, R.drawable.preview_d7, R.drawable.preview_d8, R.drawable.preview_d9};

    static int index(String kind) {
        for (int i = 0; i < KINDS.length; i++) if (KINDS[i].equals(kind)) return i;
        return -1;
    }
}
