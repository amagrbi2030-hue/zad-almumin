package com.zadalmumin.app;

/** Home-screen widget «الويدجت الليلية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD6 extends SnapWidget { }
