package com.zadalmumin.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;

public final class NotificationHelper {
    static final String CH_ADHAN = "adhan_v1";
    static final String CH_ALERT = "alerts_v1";
    static final String CH_SILENT = "silent_v1";
    static final String CH_TASKS = "tasks_v1";

    private NotificationHelper() { }

    static void createChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();

        NotificationChannel adhan = new NotificationChannel(CH_ADHAN, "الأذان", NotificationManager.IMPORTANCE_HIGH);
        adhan.setDescription("صوت الأذان عند دخول وقت الصلاة");
        adhan.setSound(null, null);
        adhan.enableVibration(true);
        adhan.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(adhan);

        NotificationChannel alert = new NotificationChannel(CH_ALERT, "الإقامة والتنبيهات", NotificationManager.IMPORTANCE_HIGH);
        alert.setDescription("الإقامة والتنبيه المسبق ومواقيت أخرى");
        alert.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), aa);
        alert.enableVibration(true);
        alert.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(alert);

        NotificationChannel silent = new NotificationChannel(CH_SILENT, "تنبيهات صامتة", NotificationManager.IMPORTANCE_DEFAULT);
        silent.setSound(null, null);
        nm.createNotificationChannel(silent);

        NotificationChannel tasks = new NotificationChannel(CH_TASKS, "المهام اليومية", NotificationManager.IMPORTANCE_HIGH);
        tasks.setDescription("تذكير بالمهام غير المكتملة وتهنئة بالمهام المكتملة");
        tasks.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), aa);
        tasks.enableVibration(true);
        tasks.setVibrationPattern(new long[]{0, 300, 150, 300});
        nm.createNotificationChannel(tasks);
    }

    static PendingIntent openApp(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @SuppressWarnings("deprecation")
    static Notification.Builder builder(Context c, String channel) {
        createChannels(c);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, channel) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_stat).setContentIntent(openApp(c)).setAutoCancel(true)
                .setShowWhen(true).setWhen(System.currentTimeMillis());
        if (Build.VERSION.SDK_INT >= 21) b.setVisibility(Notification.VISIBILITY_PUBLIC).setColor(0xFF1F6B53);
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH);
            if (!CH_SILENT.equals(channel) && !CH_ADHAN.equals(channel)) b.setDefaults(Notification.DEFAULT_ALL);
        }
        return b;
    }

    /** Task reminder in the phone's notification shade, with a «تم ✓» button that ticks the task directly. */
    static void showTask(Context c, int id, String title, String body, String date, String key) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification.Builder b = builder(c, CH_TASKS).setContentTitle(title).setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body)).setCategory(Notification.CATEGORY_REMINDER);
        if (date != null && !date.isEmpty() && key != null && !key.isEmpty()) {
            Intent i = new Intent(c, AlarmReceiver.class).setAction(AlarmReceiver.ACTION_DONE)
                    .putExtra("date", date).putExtra("key", key).putExtra("nid", id);
            PendingIntent pi = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat), "تم ✓", pi).build());
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat), "فتح المهام", openApp(c)).build());
        }
        try { nm.notify(id, b.build()); } catch (SecurityException ignored) { }
    }

    static void show(Context c, int id, String channel, String title, String body, boolean vibrate) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification.Builder b = builder(c, channel).setContentTitle(title).setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body));
        try { nm.notify(id, b.build()); } catch (SecurityException ignored) { }
    }
}
