package com.zadalmumin.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Plays the full adhan as a foreground service so it is not cut off, with a "stop" action. */
public class AdhanService extends Service {
    static final String ACTION_STOP = "com.zadalmumin.app.STOP_ADHAN";
    static final int NOTIF_ID = 7001;
    private MediaPlayer player;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopPlayback();
            stopSelf();
            return START_NOT_STICKY;
        }
        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");
        String sound = intent.getStringExtra("sound");
        float vol = intent.getFloatExtra("vol", 0.9f);

        Intent stop = new Intent(this, AdhanService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = NotificationHelper.builder(this, NotificationHelper.CH_ADHAN)
                .setContentTitle(title == null ? "حان وقت الصلاة" : title)
                .setContentText(body == null ? "" : body)
                .setOngoing(true)
                .setDeleteIntent(stopPi);
        if (Build.VERSION.SDK_INT >= 23) {
            b.addAction(new Notification.Action.Builder(null, "إيقاف الأذان", stopPi).build());
        } else {
            //noinspection deprecation
            b.addAction(0, "إيقاف الأذان", stopPi);
        }
        if (Build.VERSION.SDK_INT >= 21) b.setCategory(Notification.CATEGORY_ALARM);
        Notification n = b.build();

        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(NOTIF_ID, n);
        } catch (Exception e) {
            NotificationHelper.show(this, NOTIF_ID, NotificationHelper.CH_ALERT, title, body, true);
            stopSelf();
            return START_NOT_STICKY;
        }

        vibrate();
        play(sound, vol);
        return START_NOT_STICKY;
    }

    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 400, 200, 400}, -1));
            else {
                //noinspection deprecation
                v.vibrate(new long[]{0, 400, 200, 400}, -1);
            }
        } catch (Exception ignored) { }
    }

    private void play(String sound, float vol) {
        stopPlayback();
        int res = sound == null ? 0 : getResources().getIdentifier(sound, "raw", getPackageName());
        if (res == 0) res = R.raw.adhan1;
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            AssetFileDescriptor afd = getResources().openRawResourceFd(res);
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            player.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            player.setVolume(vol, vol);
            player.setOnCompletionListener(mp -> finish());
            player.setOnErrorListener((mp, what, extra) -> { finish(); return true; });
            player.prepare();
            player.start();
        } catch (Exception e) {
            finish();
        }
    }

    private void finish() {
        stopPlayback();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
        else {
            //noinspection deprecation
            stopForeground(false);
        }
        stopSelf();
    }

    private void stopPlayback() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) { }
            player.release();
            player = null;
        }
    }

    @Override
    public void onDestroy() {
        stopPlayback();
        super.onDestroy();
    }
}
