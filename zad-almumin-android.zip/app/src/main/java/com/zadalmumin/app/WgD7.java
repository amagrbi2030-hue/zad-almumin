package com.zadalmumin.app;

/** Home-screen widget «الإسلامية الشفافة» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD7 extends SnapWidget { }
