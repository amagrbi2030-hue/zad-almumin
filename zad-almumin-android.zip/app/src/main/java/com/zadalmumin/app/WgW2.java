package com.zadalmumin.app;

/** Home-screen widget «المساجد — مسار الصلوات» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgW2 extends SnapWidget { }
