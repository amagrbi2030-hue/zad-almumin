package com.zadalmumin.app;

/** Home-screen widget «لوحة الصلوات اليومية» — image frames rendered by the app (studio look), see WidgetUpdater. */
public class WgD4 extends SnapWidget { }
