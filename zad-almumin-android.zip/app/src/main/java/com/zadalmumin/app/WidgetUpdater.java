package com.zadalmumin.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.os.SystemClock;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.io.File;
import java.util.Calendar;

/** Renders the two home-screen widgets from natively computed prayer times (no internet, no app launch needed). */
public final class WidgetUpdater {
    private WidgetUpdater() { }

    private static final int[] N = {R.id.n0, R.id.n1, R.id.n2, R.id.n3, R.id.n4, R.id.n5};
    private static final int[] T = {R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5};
    private static final int[] C = {R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5};
    private static final int[] CI = {R.id.ci0, R.id.ci1, R.id.ci2, R.id.ci3, R.id.ci4, R.id.ci5};
    private static final int[] CB = {R.id.cb0, R.id.cb1, R.id.cb2, R.id.cb3, R.id.cb4, R.id.cb5};
    private static final int[] KB = {R.id.kb0, R.id.kb1, R.id.kb2, R.id.kb3, R.id.kb4, R.id.kb5};
    private static final int[] CN = {R.id.cn0, R.id.cn1, R.id.cn2, R.id.cn3, R.id.cn4, R.id.cn5};
    private static final int[] CT = {R.id.ct0, R.id.ct1, R.id.ct2, R.id.ct3, R.id.ct4, R.id.ct5};
    private static final int[] ICONS = {R.drawable.ic_w_fajr, R.drawable.ic_w_sunrise, R.drawable.ic_w_dhuhr,
            R.drawable.ic_w_asr, R.drawable.ic_w_maghrib, R.drawable.ic_w_isha};

    static void updateAll(Context ctx) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
            int[] dayIds = mgr.getAppWidgetIds(new ComponentName(ctx, DayWidget.class));
            int[] capIds = mgr.getAppWidgetIds(new ComponentName(ctx, CapsWidget.class));
            boolean anySnap = false;
            for (Class<?> k : SnapKinds.CLASSES) if (mgr.getAppWidgetIds(new ComponentName(ctx, k)).length > 0) { anySnap = true; break; }
            if (dayIds.length == 0 && capIds.length == 0 && !anySnap) return;

            JSONObject cfg = Planner.cfg(ctx);
            long now = System.currentTimeMillis();
            Calendar cal = Calendar.getInstance(Planner.tz(cfg));
            cal.setTimeInMillis(now);
            int y = cal.get(Calendar.YEAR), m = cal.get(Calendar.MONTH) + 1, d = cal.get(Calendar.DATE);
            boolean fri = cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY;
            long[] t = Planner.day(cfg, y, m, d);

            int next = -1;
            long nextAt = 0;
            for (int i = 0; i < 6; i++) if (t[i] > now) { next = i; nextAt = t[i]; break; }
            if (next < 0) {
                Calendar tm = (Calendar) cal.clone();
                tm.add(Calendar.DATE, 1);
                long[] t2 = Planner.day(cfg, tm.get(Calendar.YEAR), tm.get(Calendar.MONTH) + 1, tm.get(Calendar.DATE));
                next = 0; nextAt = t2[0];
            }

            PendingIntent open = NotificationHelper.openApp(ctx);
            JSONObject wl = cfg.optJSONObject("widgets");
            Look dayL = Look.from(wl == null ? null : wl.optJSONObject("day"), false);
            Look capL = Look.from(wl == null ? null : wl.optJSONObject("caps"), true);
            float dn = ctx.getResources().getDisplayMetrics().density;

            for (int id : dayIds) {
                RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_day);
                rv.setOnClickPendingIntent(R.id.root, open);
                int[] sz = sizeDp(mgr, id, 300, 130);
                rv.setImageViewBitmap(R.id.bg, Look.panel(dayL, sz[0], sz[1], dn));
                int wd = cal.get(Calendar.DAY_OF_WEEK) - 1; // 0 = Sunday
                rv.setImageViewResource(R.id.img_wd, res(ctx, "wd_" + wd));
                rv.setImageViewResource(R.id.img_gm, res(ctx, "gm_" + (m - 1)));
                int hm = hijriMonth(cfg, now);
                if (hm >= 0) rv.setImageViewResource(R.id.img_hm, res(ctx, "hm_" + hm));
                for (int img : new int[]{R.id.img_wd, R.id.img_gm, R.id.img_hm}) rv.setInt(img, "setColorFilter", dayL.text);
                rv.setInt(R.id.sv1, "setBackgroundColor", Look.alpha(dayL.frame, .9f));
                rv.setInt(R.id.sv2, "setBackgroundColor", Look.alpha(dayL.frame, .9f));
                rv.setInt(R.id.sh, "setBackgroundColor", Look.alpha(dayL.frame, .7f));
                boolean light = Look.lum(dayL.text) < .45;
                for (int i = 0; i < 6; i++) {
                    boolean on = i == next;
                    String nm = Planner.name(Planner.SIX[i], fri);
                    rv.setTextViewText(N[i], on ? bold(nm) : nm);
                    rv.setTextColor(N[i], on ? dayL.ind : Look.alpha(dayL.text, .66f));
                    rv.setTextViewTextSize(N[i], TypedValue.COMPLEX_UNIT_SP, 12f * dayL.fs);
                    rv.setTextViewText(T[i], Planner.fmt(cfg, t[i], false));
                    rv.setTextColor(T[i], dayL.text);
                    rv.setTextViewTextSize(T[i], TypedValue.COMPLEX_UNIT_SP, 15f * dayL.fs);
                    rv.setInt(T[i], "setBackgroundResource", on ? (light ? R.drawable.wg_pill_l : R.drawable.wg_pill) : 0);
                    if (on) {
                        rv.setViewVisibility(C[i], View.VISIBLE);
                        rv.setTextColor(C[i], dayL.ind);
                        rv.setChronometer(C[i], SystemClock.elapsedRealtime() + (nextAt - now), "بعد %s", true);
                        rv.setChronometerCountDown(C[i], true);
                    } else {
                        rv.setViewVisibility(C[i], View.GONE);
                        rv.setChronometer(C[i], SystemClock.elapsedRealtime(), null, false);
                    }
                }
                mgr.updateAppWidget(id, rv);
            }

            for (int id : capIds) {
                RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_caps);
                rv.setOnClickPendingIntent(R.id.root, open);
                int[] sz = sizeDp(mgr, id, 300, 130);
                rv.setImageViewBitmap(R.id.bg, Look.capsPanel(capL, sz[0], sz[1], dn));
                android.graphics.Bitmap cap = Look.capsule(capL, (sz[0] - 32) / 6f - 4, sz[1] - 32, dn);
                android.graphics.Bitmap ring = Look.circle(capL, false, dn), dot = Look.circle(capL, true, dn);
                float fs = Math.min(capL.fs, 1.15f);
                for (int i = 0; i < 6; i++) {
                    boolean on = i == next;
                    rv.setImageViewBitmap(KB[i], cap);
                    rv.setImageViewResource(CI[i], ICONS[i]);
                    rv.setInt(CI[i], "setColorFilter", capL.icon);
                    rv.setImageViewBitmap(CB[i], on ? dot : ring);
                    rv.setTextViewText(CN[i], Planner.name(Planner.SIX[i], fri));
                    rv.setTextViewText(CT[i], Planner.fmt(cfg, t[i], false));
                    int col = on ? capL.on : capL.text;
                    rv.setTextColor(CN[i], col);
                    rv.setTextColor(CT[i], col);
                    rv.setTextViewTextSize(CN[i], TypedValue.COMPLEX_UNIT_SP, 9.5f * fs);
                    rv.setTextViewTextSize(CT[i], TypedValue.COMPLEX_UNIT_SP, 9f * fs);
                }
                mgr.updateAppWidget(id, rv);
            }

            long nextSnap = Long.MAX_VALUE;
            for (int s = 0; s < SnapKinds.KINDS.length; s++) {
                int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, SnapKinds.CLASSES[s]));
                if (ids.length == 0) continue;
                JSONObject meta = snapMeta(ctx, SnapKinds.KINDS[s]);
                android.graphics.Bitmap bmp = null;
                if (meta != null) {
                    org.json.JSONArray fr = meta.optJSONArray("frames");
                    String file = null;
                    for (int i = 0; fr != null && i < fr.length(); i++) {
                        org.json.JSONArray f = fr.getJSONArray(i);
                        long from = f.getLong(0);
                        if (from <= now) file = f.getString(1);
                        else nextSnap = Math.min(nextSnap, from);
                    }
                    if (file == null && fr != null && fr.length() > 0) file = fr.getJSONArray(0).getString(1);
                    if (file != null) {
                        try { bmp = BitmapFactory.decodeFile(new File(snapDir(ctx), file).getPath()); } catch (Throwable ignored) { }
                    }
                }
                for (int id : ids) {
                    RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_snap);
                    rv.setOnClickPendingIntent(R.id.root, open);
                    if (bmp != null) rv.setImageViewBitmap(R.id.img, bmp);
                    else rv.setImageViewResource(R.id.img, SnapKinds.PREVIEWS[s]);
                    JSONObject ck = meta == null || bmp == null ? null : meta.optJSONObject("clock");
                    rv.setViewVisibility(R.id.clk, View.GONE);
                    rv.setViewVisibility(R.id.clkc, View.GONE);
                    if (ck != null) applyClock(rv, ck, meta, sizeDp(mgr, id, 250, 110));
                    mgr.updateAppWidget(id, rv);
                }
            }

            // refresh again at the next prayer time or just after midnight, whichever comes first
            Calendar mid = (Calendar) cal.clone();
            mid.add(Calendar.DATE, 1);
            mid.set(Calendar.HOUR_OF_DAY, 0); mid.set(Calendar.MINUTE, 0); mid.set(Calendar.SECOND, 30); mid.set(Calendar.MILLISECOND, 0);
            scheduleNext(ctx, Math.min(Math.min(nextAt + 30000L, mid.getTimeInMillis()), nextSnap));
        } catch (Exception ignored) { }
    }

    static File snapDir(Context c) {
        File d = new File(c.getFilesDir(), "wg");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static JSONObject snapMeta(Context c, String kind) {
        try {
            String s = Scheduler.prefs(c).getString("wgm." + kind, null);
            return s == null ? null : new JSONObject(s);
        } catch (Exception e) { return null; }
    }

    /** Live clock (TextClock) laid over the frame exactly where the design draws its time. */
    private static void applyClock(RemoteViews rv, JSONObject ck, JSONObject meta, int[] sz) {
        float W = sz[0], H = sz[1];
        float iw = (float) meta.optDouble("w", 1), ih = (float) meta.optDouble("h", 1);
        float sc = Math.min(W / iw, H / ih), rw = iw * sc, rh = ih * sc, rx = (W - rw) / 2f, ry = (H - rh) / 2f;
        int clk;
        if (Build.VERSION.SDK_INT >= 31) {
            clk = R.id.clk;
            rv.setViewLayoutMargin(clk, RemoteViews.MARGIN_LEFT, rx + (float) ck.optDouble("x", 0) * rw, TypedValue.COMPLEX_UNIT_DIP);
            rv.setViewLayoutMargin(clk, RemoteViews.MARGIN_TOP, ry + (float) ck.optDouble("y", 0) * rh, TypedValue.COMPLEX_UNIT_DIP);
            rv.setViewLayoutWidth(clk, (float) ck.optDouble("w", .3) * rw, TypedValue.COMPLEX_UNIT_DIP);
            rv.setViewLayoutHeight(clk, (float) ck.optDouble("h", .2) * rh, TypedValue.COMPLEX_UNIT_DIP);
        } else {
            clk = R.id.clkc;
        }
        rv.setViewVisibility(clk, View.VISIBLE);
        rv.setTextViewTextSize(clk, TypedValue.COMPLEX_UNIT_DIP, (float) ck.optDouble("fs", .2) * rh * .95f);
        rv.setTextColor(clk, Look.col(ck.optString("color"), 0xFFFFFFFF));
        String f = meta.optBoolean("h24", false) ? "HH:mm" : "h:mm";
        rv.setCharSequence(clk, "setFormat12Hour", f);
        rv.setCharSequence(clk, "setFormat24Hour", f);
        String tz = meta.optString("tz", "");
        if (!tz.isEmpty()) rv.setString(clk, "setTimeZone", tz);
    }

    /** Current widget size in dp (portrait: min width × max height), with sane fallbacks. */
    private static int[] sizeDp(AppWidgetManager mgr, int id, int dw, int dh) {
        int w = 0, h = 0;
        try {
            Bundle o = mgr.getAppWidgetOptions(id);
            w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH);
            h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT);
        } catch (Exception ignored) { }
        return new int[]{w > 60 ? w : dw, h > 40 ? h : dh};
    }

    private static CharSequence bold(String s) {
        SpannableString sp = new SpannableString(s);
        sp.setSpan(new StyleSpan(Typeface.BOLD), 0, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sp;
    }

    private static int res(Context c, String name) {
        return c.getResources().getIdentifier(name, "drawable", c.getPackageName());
    }

    static int hijriMonth(JSONObject cfg, long now) {
        try {
            JSONObject calc = cfg.optJSONObject("calc");
            int adj = calc == null ? 0 : calc.optInt("hijriAdjust", 0);
            android.icu.util.IslamicCalendar ic = new android.icu.util.IslamicCalendar(
                    android.icu.util.TimeZone.getTimeZone(Planner.tz(cfg).getID()));
            ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            ic.setTimeInMillis(now + adj * 86400000L);
            return ic.get(android.icu.util.Calendar.MONTH);
        } catch (Throwable e) {
            return -1;
        }
    }

    private static void scheduleNext(Context c, long at) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("ev", "{\"type\":\"widget\"}");
        PendingIntent pi = PendingIntent.getBroadcast(c, 900, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }
}
